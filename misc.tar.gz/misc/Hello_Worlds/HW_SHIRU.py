#Author: Shiru Hou
#Date: February 16, 2017
print "Hello World"