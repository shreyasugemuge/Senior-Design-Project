#Author: Mohammed Alhabsi
#Date: February 19, 2017
print "Hello World"