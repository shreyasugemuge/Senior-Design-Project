#Author: Yaqeen Alkathiri
#Date: February 16, 2017
print "Hello World"
