#Author: Shreyas Ugemuge
#Date: February 16, 2017
print "Hello World"
