These are files made as test commits to make sure all repositories are in the same place.
This also facilitated as a tutorial and was completed 5/2/17.
